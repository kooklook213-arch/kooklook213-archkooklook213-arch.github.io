import { GradientCanvas } from "@/components/gradient-canvas"
import { LoginForm } from "@/components/login-form"

export default function LoginPage() {
  return (
    <main className="flex min-h-dvh w-full flex-col lg:flex-row">
      <section className="login-panel flex min-h-dvh w-1/2 items-center justify-center bg-white" aria-label="Sign in">
        <LoginForm />
      </section>
      <section className="login-atmosphere min-h-dvh w-1/2" aria-label="Atmospheric background">
        <GradientCanvas />
      </section>
    </main>
  )
}
