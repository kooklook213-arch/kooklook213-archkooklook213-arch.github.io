"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export function LoginForm() {
  const [showOptions, setShowOptions] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  return (
    <div className="flex min-h-dvh w-full items-center justify-center bg-white">
      <div className="w-full max-w-sm space-y-6 px-4">
        <div className="text-center">
          <h1 className="text-lg font-medium tracking-tight">Welcome Back!</h1>
          <p className="text-xs text-muted-foreground">Enter your credentials to access your account</p>
        </div>

        <div className="space-y-4">
          <Button type="button" className="h-11 w-full rounded-none border-0 bg-neutral-900 text-neutral-50 shadow-none transition-colors duration-200 ease hover:bg-neutral-800">
            <svg aria-hidden="true" className="h-5 w-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
            </svg>
            Continue with Google
          </Button>

          <div className="relative flex items-center justify-center">
            <span className="text-xs text-muted-foreground">or</span>
          </div>

          <Button type="button" onClick={() => setShowOptions((visible) => !visible)} className="h-11 w-full rounded-none bg-muted text-muted-foreground shadow-none transition-colors duration-200 ease hover:bg-muted/80">
            {showOptions ? "Hide options" : "Show other options"}
          </Button>

          {showOptions && (
            <form className="space-y-3" onSubmit={(event) => { event.preventDefault(); setSubmitted(true) }}>
              <label className="sr-only" htmlFor="email">Email address</label>
              <input id="email" name="email" type="email" required placeholder="Email address" className="h-11 w-full border border-border bg-white px-3 text-sm outline-none ring-offset-2 focus-visible:ring-2 focus-visible:ring-ring" />
              <label className="sr-only" htmlFor="password">Password</label>
              <input id="password" name="password" type="password" required placeholder="Password" className="h-11 w-full border border-border bg-white px-3 text-sm outline-none ring-offset-2 focus-visible:ring-2 focus-visible:ring-ring" />
              <Button type="submit" className="h-11 w-full rounded-none">Sign in</Button>
              {submitted && <p role="status" className="text-center text-xs text-muted-foreground">Sign-in details received.</p>}
            </form>
          )}

          <p className="text-center text-xs text-muted-foreground">
            Don&apos;t have an account?{" "}
            <button type="button" onClick={() => setShowOptions(true)} className="underline transition-colors duration-200 ease hover:text-neutral-900">Sign up</button>
          </p>
        </div>
      </div>
    </div>
  )
}
